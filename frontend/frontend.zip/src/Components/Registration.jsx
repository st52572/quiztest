import React from 'react';
import {Input} from "./Input";

export class Registration extends React.Component {


    constructor() {
        super();
        this.state = {user:{firstName: "", lastName: ""}}
    }

    /*componentDidMount() {


            fetch('/users', { mode: "no-cors" })
                .then(response => response.json())
                //.then(response => response.body)
                .then(data => console.log(data));

    }*/

    register = ()=>{

    }

    changeFirstName = (firstName) =>{
        this.setState(prevState => {
            let user = { ...prevState.user };  // creating copy of state variable jasper
            user.firstName = firstName;                     // update the name property, assign a new value
            return { user };                                 // return new object jasper object
        })
    }
    changeLastName = (lastName) =>{
        this.setState(prevState => {
            let user = { ...prevState.user };  // creating copy of state variable jasper
            user.lastName = lastName;                     // update the name property, assign a new value
            return { user };                                 // return new object jasper object
        })
    }

    render() {
        return (
            <div>
                <Input type={"text"} onChange={this.changeFirstName} text={"firstName"}/>
                <Input type={"text"} onChange={this.changeLastName} text={"lastName"}/>
                <button onClick={this.register}>Registrovat</button>
            </div>
        )
    }


}