import React from 'react';
import {Input} from "./Input";

export class Login extends React.Component {


    constructor() {
        super();
        this.state = {user: {login: "", password: ""}}
    }

    /*componentDidMount() {


        fetch('/users', { mode: "no-cors" })
            .then(response => response.json())
            //.then(response => response.body)
            .then(data => console.log(data));

    }*/

    login = ()=>{

    }

    changeLogin = (login) => {
        this.setState(prevState => {
            let user = {...prevState.user};  // creating copy of state variable jasper
            user.login = login;                     // update the name property, assign a new value
            return {user};                                 // return new object jasper object
        })
    }
    changePassword = (password) => {
        this.setState(prevState => {
            let user = {...prevState.user};  // creating copy of state variable jasper
            user.password = password;                     // update the name property, assign a new value
            return {user};                                 // return new object jasper object
        })
    }

    render() {
        return (
            <div>
                <Input type={"text"} onChange={this.changeLogin} text={"login"}/>
                <Input type={"password"} onChange={this.changePassword} text={"password"}/>
                <button onClick={this.login}>Registrovat</button>
            </div>
        )
    }


}