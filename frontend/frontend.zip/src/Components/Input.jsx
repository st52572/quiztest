import React from 'react';
export class Input extends React.Component {


    handleChange = (event) => {
        this.props.onChange({text: event.target.value})
    }

    render() {
        return (
            <React.Fragment>
                {this.props.text}
                <input type={this.props.type} onChange={this.handleChange} />
            </React.Fragment>
        )
    }


}