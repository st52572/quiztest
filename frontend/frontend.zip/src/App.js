import React from 'react';
import './App.css';
import {Registration} from "./Components/Registration";
import {Login} from "./Components/Login";

function App() {
  return (
    <div className="App">
        <Registration/>
        <Login/>
    </div>
  );
}

export default App;
